import "./loading.css"
import React from 'react'

function Loading() {
    return (
        <div className="no-succsess-container" >
            <div className="loading-block"></div>
        </div >
    )
}

export default Loading;